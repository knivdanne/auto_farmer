Tools needed:

download and install nodejs https://nodejs.org/en/download/

download nad install ganache (local ethereum client) https://www.trufflesuite.com/ganache

create an account on infura https://infura.io/


launch cmd

npm install -g truffle

npm install -g yarn

Update truffle-config.js

